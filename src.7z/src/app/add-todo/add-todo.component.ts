import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material/dialog';
import { TodoInterface } from '../Interface/todo-interface';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-add-todo',
  templateUrl: './add-todo.component.html',
  styleUrls: ['./add-todo.component.css']
})
export class AddTodoComponent {

  selectedPriority: string = '';
  selectedStatus: string=''; 
  taskForm! : FormGroup;

    task: TodoInterface = {
      title: '',
      description: '',
      status:'todo',
      priority: 'High',
      date: new Date(),
      id: 0,
      complete_percentage:0
    };
  this: any;

 
  
    constructor(private dialog: MatDialog,
      public dialogRef: MatDialogRef<AddTodoComponent>,
      private formBuilder: FormBuilder,
      private snackBar: MatSnackBar,
      ) {}
  
      openDialog(): void {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.autoFocus = true;
        dialogConfig.width = '400px';
        dialogConfig.position = { top: '50%', left: '50%'};
        dialogConfig.panelClass = 'custom-dialog-container'; // Custom CSS class for styling the dialog container
    
        this.dialog.open(AddTodoComponent, dialogConfig);
      }
      ngOnInit(){
          this.initializeForm();
          
      }
      initializeForm() {
        // Initialize the taskForm with form controls
        this.taskForm = this.formBuilder.group({
          title: ['', Validators.required], 
          description: [''], 
          priority: ['', Validators.required], 
          date: [null,Validators.required] 
        });
     }

    addTask() {
      const isAnyFieldEmpty = !this.taskForm.get('title')?.value || !this.selectedStatus || !this.selectedPriority;
      if (isAnyFieldEmpty) {
        this.
        this.snackBar.open('Task Title, Status, and Priority are mandatory!', 'Close', {
          duration: 3000,
          horizontalPosition: 'center', 
          verticalPosition: 'top' 
        });
      } else {
        
        this.dialogRef.close(this.taskForm.value);
      }
    }
    onCancelClick() {
      this.dialogRef.close(this.task);
    }
    
  

}
