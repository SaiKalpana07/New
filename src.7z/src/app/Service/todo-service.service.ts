import { Injectable } from '@angular/core';
import { TodoInterface } from '../Interface/todo-interface';

@Injectable({
  providedIn: 'root'
})
export class TodoServiceService {

  todoList: TodoInterface[] = [
    {
      id: 1,
      title: 'Complete task',
      description: 'Module',
      status: 'inprogress',
      date: new Date('2023-08-03'),
      priority: 'High',
      complete_percentage:30
    },
    {
      id: 2,
      title: 'Watch Webseries',
      description: '2 episodes',
      status: 'completed',
      date: new Date('2023-08-04'),
      priority: 'Low',
      complete_percentage:80
    },
    {
      id: 3,
      title: 'Read a Book',
      description: 'Read an interesting novel.',
      status: 'completed',
      date: new Date('2023-08-05'),
	  priority: 'Medium',
    complete_percentage:100
    },
  ];

  getAll() {
    return this.todoList;
  }

  getChargeSheetBystatuscompleted() : TodoInterface[] {
    return this.todoList.filter((task) => task.status === 'completed')
  }
  getChargeSheetBystatusInProgress() : TodoInterface[] {
    return this.todoList.filter((task) => task.status === 'inprogress');
  }

  updateChargeSheet(_id: TodoInterface): void {
    const index = this.todoList.findIndex((todoListid) => todoListid.id === _id.id);
    if (index !== -1) {
      this.todoList[index] = _id;
    }
  }

}

