import { Component } from '@angular/core';
import { NavigationServiceService } from '../Service/navigation-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  signUp:any[]=[];
  signUpData:any={
    name:'babu',
    email:'babu@gmail.com',
    password:'Babu123.!',
  }
  loginData:any={
   name:'',
   password:'',
  }
  constructor(private navigationService: NavigationServiceService){}

  ngOnInit(): void{
    const localData = localStorage.getItem('signUp')
    if(localData != null){
      this.signUp = JSON.parse(localData);
    }
  }
  onSignUp(){
    this.signUp.push(this.signUpData)
    localStorage.setItem('signUp',JSON.stringify(this.signUp))
    this.signUpData = {
      name:'',
      email:'',
      password:'',
    }
  }

  onLogin(){
    const userExist =  this.signUp.find(s => s.name === this.loginData.name && s.password === this.loginData.password)
    if(userExist != undefined){
      this.navigationService.goToSecond();
      // alert('Success')   
    }
    else{
      alert('please check')
    }
  //   showAlert() {
  //     this.snackBar.open('This is an alert message!', 'Dismiss', {
  //       duration: 3000, // Duration in milliseconds (3 seconds in this example)
  //     });
  //   // this.loginData = {
  //   //   email:'',
  //   //   password:'',
  //   // }
  // }

}
}
